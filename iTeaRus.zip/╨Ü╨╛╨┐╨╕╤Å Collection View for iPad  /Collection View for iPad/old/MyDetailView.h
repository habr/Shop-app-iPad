//
//  MyDetailView.h
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cell2.h"
#import "Fugitive.h"
#import "MyMasterView.h"
//#import "MasterDetailDelegate.h"

@interface MyDetailView:UIViewController  <UISplitViewControllerDelegate, MasterDetailDelegate>

@property (weak, nonatomic) id <MasterDetailDelegate> delegate;

-(void) masterAction;

@property (nonatomic, strong) Fugitive *detail;

@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) NSArray *data;
@property (strong, nonatomic) NSString *key;

@end
