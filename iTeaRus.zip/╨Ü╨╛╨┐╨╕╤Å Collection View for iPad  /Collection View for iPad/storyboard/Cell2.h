/*
     File: Cell2.h
 Abstract: Custom collection view cell for image and its label.
 
  */


#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "PSTCollectionView.h"

@interface Cell2 : PSUICollectionViewCell


@property (strong, nonatomic) IBOutlet UILabel *cellTextLabel2;
@property (strong, nonatomic) IBOutlet UIImageView *cellImageView2;
@property (strong, nonatomic) IBOutlet UILabel *cellPriceLabel2;

@end
