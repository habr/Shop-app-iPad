//
//   MnoSingleton.m
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MnoSingleton.h"

@implementation MnoSingleton: NSObject

@synthesize mno;

static MnoSingleton * sharedMnoSingleton = NULL;
+(MnoSingleton *)sharedMnoSingleton {
    if (!sharedMnoSingleton || sharedMnoSingleton == NULL) {
		sharedMnoSingleton = [MnoSingleton new];
	}
    return sharedMnoSingleton;
}

- (void)dealloc {
    self.mno = nil;
    [super dealloc];
}

@end
