//
//  UIViewController+DescriptionController.h
//  Collection View for iPad
//
//  Created by Kobalt on 10.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cell2.h"
#import "Fugitive.h"

@interface DescriptionController:UIViewController

@property (nonatomic, strong) Fugitive *detail;
@property (nonatomic, strong) UIImage *image;

@property (nonatomic) int32_t on;

@property (nonatomic, strong) NSString *object1;
@property (strong, nonatomic) IBOutlet UILabel *priceDetailView2;
@property (strong, nonatomic) IBOutlet UIImageView *imageDetailView2;
@property (strong, nonatomic) IBOutlet UILabel *titleLDetailabel2;
@property (strong, nonatomic) IBOutlet UITextView *textDetailView2;
@end
