//
//  MyCell.h
//  TableView


#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell 
    {
        UILabel *cellPK3;
        UILabel *cellTextLabel3;
        UILabel *cellPriceLabel3;
        UILabel *cellLabelSnipper;
    }
    
    @property (strong, nonatomic) IBOutlet UILabel *cellTextLabel3;
    @property (strong, nonatomic) IBOutlet UILabel *cellPriceLabel3;
    @property (strong, nonatomic) IBOutlet UILabel *cellLabelSnipper;
    @property (strong, nonatomic) IBOutlet UILabel *cellPK3;


@end
