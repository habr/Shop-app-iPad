//
//  StringSingleton.m
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "StringSingleton.h"

@implementation StringSingleton: NSObject

@synthesize string;

static StringSingleton * sharedStringSingleton = NULL;
+(StringSingleton *)sharedStringSingleton {
    if (!sharedStringSingleton || sharedStringSingleton == NULL) {
		sharedStringSingleton = [StringSingleton new];
	}
    return sharedStringSingleton;
}

- (void)dealloc {
    self.string = nil;
    [super dealloc];
}

@end
