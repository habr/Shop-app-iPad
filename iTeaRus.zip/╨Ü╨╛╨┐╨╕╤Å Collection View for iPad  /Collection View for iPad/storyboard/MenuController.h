//
//  MenuController.h
//  Collection View for iPad
//
//  Created by Kobalt on 15.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "MyMasterView.h"
#import "Cell2.h"
#import "Fugitive.h"
//#import "MasterDetailDelegate.h"


@interface MenuController: UIViewController <MasterDetailDelegate> 
{
    UIProgressView *downloadProgress;
    NSDictionary *V1;
    NSDictionary *V2;
    NSString *a;
    NSString *b;

}
@property (strong, nonatomic) IBOutlet UIProgressView *downloadProgress;

@property (nonatomic, retain) NSString *a;
@property (nonatomic, retain) NSString *b;

@property (nonatomic, retain) NSDictionary *V1;
@property (nonatomic, retain) NSDictionary *V2;

@property (strong, nonatomic) IBOutlet UILabel *label1;
@property (strong, nonatomic) IBOutlet UILabel *label2;
@property (strong, nonatomic) IBOutlet UILabel *label3;
@property (strong, nonatomic) IBOutlet UILabel *label4;
@property (strong, nonatomic) IBOutlet UILabel *label5;


@end

