//
//  SumSingleton.m
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "SumSingleton.h"

@implementation SumSingleton: NSObject

@synthesize sum;
//@synthesize pk,opt,captured,captdate,capturedLat,lastSeenLat,desc,capturedLon,image,
//lastSeenLon,bounty,lastSeenDesc,imagename,name,fugitiveID;

static SumSingleton * sharedSumSingleton = NULL;
+(SumSingleton *)sharedSumSingleton {
    if (!sharedSumSingleton || sharedSumSingleton == NULL) {
		sharedSumSingleton = [SumSingleton new];
	}
    return sharedSumSingleton;
}

- (void)dealloc {
    self.sum = nil;
    [super dealloc];
}

@end
