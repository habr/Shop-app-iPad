//
//  MenuController.m
//  Collection View for iPad
//
//  Created by Kobalt on 15.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.

#import "MenuController.h"
#import "KeySingleton.h"
#import "APIDownload.h"
#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]

@interface MenuController ()

@end

@implementation MenuController
@synthesize downloadProgress;
@synthesize V1, a, b;
@synthesize V2;
@synthesize label1,label2,label3,label4,label5;

- (void)dealloc {

    self.downloadProgress = nil;
    [super dealloc];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    downloadProgress.hidden = YES;   
    //                              Проверяем дату базы на сервере
    NSString *stringURL = @"http://ichiya.ucoz.ru/iBountyHunter.sqlite";
    NSURL *aURL = [NSURL URLWithString:stringURL];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:aURL];
    NSHTTPURLResponse *response;
    [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    if( [response respondsToSelector:@selector( allHeaderFields )] )
    {
        NSDictionary *metaData = [response allHeaderFields];
        NSString *lastModifiedString = [metaData objectForKey:@"Last-Modified"];
        a=lastModifiedString;
    }
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc] init];          //проеобразовываем в другой формат
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormater setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    [dateFormater setLocale:locale];
    [dateFormater setDateFormat:@"EEE, dd MMM yyyy HH:mm:ss ZZZ"];
    NSDate *datetime1 = [dateFormater dateFromString:a];
    a=[dateFormater stringFromDate:datetime1];
    
    
    NSLog(@"a %@",datetime1);

    //                              Проверяем дату базы на устройстве
    NSString  *filePath = [NSString stringWithFormat:@"%@/%@", DOCUMENTS,@"iBountyHunter.sqlite"];
    NSDictionary *attributes = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
    
    NSDate *date = [attributes fileModificationDate];
//    NSDateFormatter *dateFormatter = [[NSDateFormatter new] autorelease];
//    NSLocale *locale2 = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
//    [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
//    [dateFormatter setLocale:locale2];
//    [dateFormatter setDateFormat:@"EEE, dd MMM yyyy HH:mm:ss"];
//    NSString *c=@"GMT";
//    b=[NSString stringWithFormat:@"%@ %@", [dateFormatter stringFromDate:date], c];
    NSDate *datetime2 = date;
    NSLog(@"b %@",datetime2);
    b=[dateFormater stringFromDate:datetime2];
    label1.text = a;
    label2.text = b;
    //                              Сравнение версий базы
    if ([datetime1 earlierDate:datetime2]==datetime2){
        label4.text = (@"D1 ");
        downloadProgress.hidden = NO;
        [APIDownload downloadWithURL:@"http://ichya.hostenko.com/iBountyHunter.sqlite" delegate:self];
    }
    if (datetime2==NULL){
        label5.text = (@"D2 ");
        downloadProgress.hidden = NO;
        [APIDownload downloadWithURL:@"http://ichya.hostenko.com/iBountyHunter.sqlite" delegate:self];
    }
    if (datetime2==NULL & datetime1==NULL){ 
        downloadProgress.hidden = NO; //YES
        NSString *const kDatabaseFileName = @"iBountyHunter.sqlite";
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *databasePath = [DOCUMENTS stringByAppendingPathComponent:kDatabaseFileName];
        //   [fileManager removeItemAtPath:databasePath error:NULL]; // удаление базы
        if (![fileManager fileExistsAtPath:databasePath]) {
            NSString *defaultDatabasePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:kDatabaseFileName];
            [fileManager copyItemAtPath:defaultDatabasePath toPath:databasePath error:nil];
        label3.text=@"Load default Data Base";
        }
    }
}
- (void)APIDownload:(APIDownload*)request {
    downloadProgress.hidden = NO; //YES
    NSString *filePath1 = [DOCUMENTS stringByAppendingPathComponent:@"iBountyHunter.sqlite"];
    [request.downloadData writeToFile:filePath1 atomically:YES];
}

- (void)dataDownloadAtPercent:(NSNumber*)percent {
    downloadProgress.progress = [percent floatValue];
}


-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}
- (IBAction)buttonGo:(id)sender {
    
}


- (void)viewDidUnload {
  //  [self setProgressBar:nil];
  //  [self setButtonGo:nil];
    [self setLabel1:nil];
    [self setLabel2:nil];
    [self setLabel3:nil];
    [self setLabel4:nil];
    [self setLabel5:nil];
    [super viewDidUnload];
}
@end
