//
//  MasterDetaiDelegate.h
//  Collection View for iPad
//
//  Created by Kobalt on 09.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MasterDetailDelegate <NSObject>
-(void) masterAction;
@end
@interface MasterDetailDelegate :NSObject{
    id <MasterDetailDelegate> delegate;
}

@property (weak, nonatomic) id <MasterDetailDelegate> delegate;

@end