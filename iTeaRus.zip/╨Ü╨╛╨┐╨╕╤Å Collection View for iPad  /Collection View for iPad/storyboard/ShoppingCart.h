//
//
//  ShoppingCart.h
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "Fugitive.h"
#import "MnoSingleton.h"

@interface ShoppingCart: UIViewController <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *arrayA;
    NSMutableArray *arrayB;
//    NSMutableArray *arrayADC;
}

@property (strong, nonatomic) IBOutlet UILabel *backgroundText;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UILabel *totalSum;

+ (ShoppingCart *)sharedInstance;
- (void)refreshData;
- (void)refreshload;

@property (nonatomic, strong) Fugitive *detail;
@property (strong, nonatomic) NSArray *data;

@property (nonatomic) int32_t on;

@property (nonatomic,retain) NSMutableArray *values;

@property (nonatomic,retain) NSMutableArray *arrayA;
@property (nonatomic,retain) NSMutableArray *arrayB;
@property (nonatomic,retain) NSMutableArray *arrayADC;

@property (nonatomic,retain) NSMutableArray *a;
@property (nonatomic) CGFloat minValue;
@property (nonatomic) CGFloat maxValue;

@end
