//
//  MenuController.h
//  Collection View for iPad
//
//  Created by Kobalt on 15.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "MyMasterView.h"
#import "Cell2.h"
#import "Fugitive.h"
//#import "MasterDetailDelegate.h"


@interface MenuController2: UIViewController <MasterDetailDelegate>
{
    MyMasterView *master;
    NSDictionary *V1;
    NSDictionary *V2;
    NSString *a;
    NSString *b;
    
    
    
}


@property (strong, nonatomic) NSArray *data;
@property (strong, nonatomic) NSString *object;

-(IBAction)ButtonMenu1: (id)sender;
-(IBAction)ButtonMenu2: (id)sender;
-(IBAction)ButtonMenu3: (id)sender;
-(IBAction)ButtonMenu4: (id)sender;

-(void) masterAction;


@property (nonatomic, retain) NSDictionary *V1;
@property (nonatomic, retain) NSDictionary *V2;



@end

