//  delegate
//  MyMasterTableView.m
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MyMasterView.h"
#import "Cell2.h"
#import "FMDatabase+SharedInstance.h"
#import "EXClient.h"
//#import "MyDetailView.h"
#import "Fugitive.h"
#import "KeySingleton.h"
#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]


@implementation MyMasterView:UIViewController

@synthesize object;
@synthesize delegate=_delegate;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    [KeySingleton sharedKeySingleton].key =@"1";
	// Do any additional setup after loading the view, typically from a nib.
    [self masterAction];

}



-(IBAction)Button1: (id)sender{
    self.object=[NSString stringWithFormat:@"1"];
    [KeySingleton sharedKeySingleton].key =object;
    [self masterAction];
    //[self autoAlert];
}

-(IBAction)Button2: (id)sender{
    self.object=[NSString stringWithFormat:@"2"];
    [KeySingleton sharedKeySingleton].key =object;
    [self masterAction];
}

-(IBAction)Button3: (id)sender{
    self.object=[NSString stringWithFormat:@"3"];
    [KeySingleton sharedKeySingleton].key =object;
    [self masterAction];
}

-(IBAction)Button4: (id)sender{
    self.object=[NSString stringWithFormat:@"4"];
    [KeySingleton sharedKeySingleton].key =object;
    [self masterAction];
}


#pragma mark - Managing the detail item

- (void)setdetail:(id)newdetail
{
    if (_detail != newdetail) {
        _detail = newdetail;
        
        [self refreshData];
    }
}
//выввести коллекцию на борд

- (id)initWithNibName: (NSString *)nibNameOrNil bundle: (NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;}

//- (void)configureView{
//    if (self.detail) {
//
//    }}


- (NSInteger)collectionView:(PSUICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return [self.data count];
}

- (UICollectionViewCell *)collectionView:(PSUICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    static NSString *const CellID = @"cellID2";       // связка ячейки кода через идентефикатор
    
    Cell2 *cell2 = [cv dequeueReusableCellWithReuseIdentifier:CellID forIndexPath:indexPath];   // создание ячейки
    
    Fugitive *item = [self.data objectAtIndex:indexPath.row];
    
    cell2.cellTextLabel2.text = item.name;
    cell2.cellPriceLabel2.text = item.bounty;
    cell2.cellImageView2.image = [UIImage imageNamed:item.imagename];
    if (cell2.cellImageView2.image == 0){
        NSString *nameImage=item.imagename;
        NSString *filePath = [DOCUMENTS stringByAppendingPathComponent:nameImage];
        UIImage *images= [UIImage imageWithContentsOfFile:filePath];
        cell2.cellImageView2.image=images;
    }
    
 //   NSLog(@"%d", indexPath.row);
    return cell2;
    
}

- (void)refreshData
{
    [[EXClient sharedInstance] fetchRssFeedCachedBlock:^(NSArray *result) {
        self.data = result;
        [self.collectionView reloadData];
    }];
}



- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"ShowSightingDetails"]) {
        NSIndexPath *selectedIndexPath = [[self.collectionView indexPathsForSelectedItems] objectAtIndex:0];
        Fugitive *item = [self.data objectAtIndex:selectedIndexPath.row];
        [segue.destinationViewController setDetail:item];}
}

#pragma mark - Master Detail Delegate

-(void) masterAction;
{    
    [self refreshData];

}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}

@end
