//
//  MyArraySingleton
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyArraySingleton: NSObject {
    NSMutableArray *mAS;
}
@property (nonatomic, retain) NSMutableArray *mAS;

+(MyArraySingleton *)sharedMyArraySingleton;

@end
