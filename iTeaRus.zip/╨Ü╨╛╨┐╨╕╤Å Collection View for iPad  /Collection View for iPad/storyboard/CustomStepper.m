//
//  CustomStepper.m
//  Andromeda
//
//  Created by Alexey Prazhenik on 13.06.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomStepper.h"
#import "QuartzCore/QuartzCore.h"

@implementation CustomStepper
@synthesize minimumValue = _minValue;
@synthesize maximumValue = _maxValue;
@synthesize value = _value;
@synthesize stepValue = _stepValue;

- (void)updateButtons
{
    [_decButton setEnabled:(_value != _minValue)];
    [_incButton setEnabled:(_value != _maxValue)];
}

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.frame = CGRectZero;
        
        _decButton = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
        [_decButton addTarget:self action:@selector(decAction) forControlEvents:UIControlEventTouchUpInside];
        [_decButton setBackgroundImage:[UIImage imageNamed:@"CustomStepperLeftOn"] forState:UIControlStateNormal];
        [_decButton setBackgroundImage:[UIImage imageNamed:@"CustomStepperLeftOff"] forState:UIControlStateDisabled];
        [self addSubview:_decButton];
        
        _incButton = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
        [_incButton addTarget:self action:@selector(incAction) forControlEvents:UIControlEventTouchUpInside];
        [_incButton setBackgroundImage:[UIImage imageNamed:@"CustomStepperRightOn"] forState:UIControlStateNormal];
        [_incButton setBackgroundImage:[UIImage imageNamed:@"CustomStepperRightOff"] forState:UIControlStateDisabled];
        [self addSubview:_incButton];
        
    }
    return self;
}

- (void)decAction
{
    if (self.value - 1 >= _minValue)
    {
        _value--;
        [self sendActionsForControlEvents:UIControlEventValueChanged];
        [self updateButtons];
    }
}

- (void)incAction
{
    if (self.value + 1 <= _maxValue)
    {
        _value++;
        [self sendActionsForControlEvents:UIControlEventValueChanged];
        [self updateButtons];
    }
}

- (void)setFrame:(CGRect)newFrame
{
    super.frame = CGRectMake(newFrame.origin.x, newFrame.origin.y, 94, 27);
    _decButton.frame = CGRectMake(0, 0, 47, 27);
    _incButton.frame = CGRectMake(47, 0, 47, 27);
}

- (void)setValue:(CGFloat)value
{
    _value = value;
    [self updateButtons];
}

@end
