//
//  UITableView+MyMasterTableView.m
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MyMasterTableView.h"
#import "ViewController.h"
#import "DetailViewController.h"
#import "Cell2.h"
#import "FMDatabase+SharedInstance.h"
#import "Fugitive.h"
#import "EXClient.h"



@interface MyMasterTableView()
- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;
@end

@implementation MyMasterTableView

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mydetailViewController = (MyDetailView *)[[self.splitViewController.viewControllers lastObject] topViewController];

}

#pragma mark - Table View

- (IBAction)ButtonShu:(id)sender {
    


}

- (IBAction)ButtonShen:(id)sender {

}

- (IBAction)ButtonRed:(id)sender {

}

- (IBAction)ButtonGreen:(id)sender {

}

- (IBAction)ButtonUlun:(id)sender {

}

- (IBAction)ButtonWhite:(id)sender {

}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.data count];
}
@end
