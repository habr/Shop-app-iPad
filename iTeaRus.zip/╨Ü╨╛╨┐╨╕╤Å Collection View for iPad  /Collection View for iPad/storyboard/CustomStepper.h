//
//  CustomStepper.h
//  Andromeda
//
//  Created by Alexey Prazhenik on 13.06.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomStepper : UIControl
{
    UIButton *_decButton;
    UIButton *_incButton;
}

@property (nonatomic) CGFloat minimumValue;
@property (nonatomic) CGFloat maximumValue;
@property (nonatomic) CGFloat value;
@property (nonatomic) CGFloat stepValue;

@end
