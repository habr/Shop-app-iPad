//
//   MnoSingleton.m
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MyArraySingleton.h"

static MyArraySingleton* sharedMyArraySingleton;

@implementation MyArraySingleton

@synthesize mAS;

+(MyArraySingleton *)sharedMyArraySingleton {
    if ( !sharedMyArraySingleton) {
		sharedMyArraySingleton = [[MyArraySingleton alloc] init];
	}    
    return sharedMyArraySingleton;
}

- (id)init
{
    self = [super init];
    if ( self )
    {
        mAS = [[NSMutableArray alloc] init];
    }
    return self;
}


//- (void)dealloc {
//    self.mAS = nil;
//    [super dealloc];
//}

@end
