//
//  MenuController2.m
//  Collection View for iPad
//
//  Created by Kobalt on 15.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.

#import "MenuController2.h"
#import "KeySingleton.h"

#import "APIDownload.h"
#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]

@interface MenuController2 ()

@end

@implementation MenuController2

@synthesize V1;
@synthesize V2;

@synthesize object;


- (void)dealloc {


    [super dealloc];
}
- (void)viewDidLoad
{
     [super viewDidLoad];
    //
    master = [[MyMasterView alloc] init];
    master.delegate = self;

}


-(IBAction)ButtonMenu1: (id)sender{
    self.object=[NSString stringWithFormat:@"1"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}

-(IBAction)ButtonMenu2: (id)sender{
    self.object=[NSString stringWithFormat:@"2"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
    NSLog(@"%@",object);

}

-(IBAction)ButtonMenu3: (id)sender{
    self.object=[NSString stringWithFormat:@"3"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}


-(IBAction)ButtonMenu4: (id)sender{
    self.object=[NSString stringWithFormat:@"4"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}

- (void)viewDidUnload {
    [super viewDidUnload];
}
@end
