//
//  UITableView+MyMasterTableView.h
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyDetailView;
@interface MyMasterTableView:UITableViewController

@property (strong, nonatomic) MyDetailView *mydetailViewController;
//@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSArray *data;
@property (strong, nonatomic) NSString *key;

@end
