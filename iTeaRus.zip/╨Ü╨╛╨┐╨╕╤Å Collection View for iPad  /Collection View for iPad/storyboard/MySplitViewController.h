//
//  UISplitViewController+MySplitViewController.h
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MySplitViewController:UISplitViewController 

@end
