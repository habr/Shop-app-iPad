//
//  SumSingleton.h
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SumSingleton: NSObject
{
 int32_t sum;
}

@property (nonatomic) int32_t sum;

+(SumSingleton *)sharedSumSingleton;


@end
