//
//  MyCell.m
//  TableView


#import "MyCell.h"

@implementation MyCell

@synthesize cellPK3;
@synthesize cellTextLabel3;
@synthesize cellPriceLabel3;
@synthesize cellLabelSnipper;

- (void)dealloc
{
    [cellTextLabel3 release];
    [cellPriceLabel3 release];
    [cellLabelSnipper release];
    [cellPK3 release];
    [super dealloc];
}

@end
