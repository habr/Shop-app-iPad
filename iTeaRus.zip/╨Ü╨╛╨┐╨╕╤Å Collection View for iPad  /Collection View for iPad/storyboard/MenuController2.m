//
//  MenuController2.m
//  Collection View for iPad
//
//  Created by Kobalt on 15.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.

#import "MenuController2.h"
#import "KeySingleton.h"
#import "EXClient.h"
#import "APIDownload.h"
#import "ASIHTTPRequest.h"

#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]

@interface MenuController2 ()

@end

@implementation MenuController2
{
    NSString *nameImage;
    NSString *urlName;
}
@synthesize V1;
@synthesize V2;

@synthesize object;


- (void)dealloc {


    [super dealloc];
}
- (void)viewDidLoad
{
     [super viewDidLoad];
    //
    master = [[MyMasterView alloc] init];
    master.delegate = self;

}
- (IBAction)mail:(id)sender {
    NSString *recipients = @"mailto:myemail@gmail.com?subject=subjecthere";
    NSString *body = @"&body=bodyHere";
    
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
    email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

- (IBAction)ButtonTest:(id)sender {

    [self refreshData];
    
    for (Fugitive *obj in  self.data)
    {
        test.image = [UIImage imageNamed:obj.imagename];
        self.filePath = [DOCUMENTS stringByAppendingPathComponent:obj.imagename];
        test2.image=[UIImage imageWithContentsOfFile:self.filePath];
       
        if(test.image == 0){
            if (test2.image == 0)
            {
                nameImage=obj.imagename;
                self.filePath = [DOCUMENTS stringByAppendingPathComponent:nameImage];
                urlName = ([NSString stringWithFormat:@"http://ichay.hostenko.com/%@", nameImage]);
                NSLog(@"%@", urlName);
                NSURL *url = [NSURL URLWithString:urlName];
                ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
                [request setDownloadDestinationPath:_filePath];
                [request setDownloadProgressDelegate:_progressString];
                [request startSynchronous];
                UIImage *images= [UIImage imageWithContentsOfFile:self.filePath];
                test.image=images;
                NSError *error = [request error];
                if (!error) {
                    NSString *response = [request responseString];
                    NSLog(@"%@",response);
                }
                    else {
                        NSLog(@"Errore");
                    }
            }
        }
    }   
}


- (void)refreshData
{
    [[EXClient sharedInstance] fetchAll:^(NSArray *resaltKol) {
        self.data = resaltKol;
    }];
}


- (void)dataDownloadAtPercent:(NSNumber*)percent {
    _progressString.progress = [percent floatValue];
}



-(IBAction)ButtonMenu1: (id)sender{
    self.object=[NSString stringWithFormat:@"1"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}

-(IBAction)ButtonMenu2: (id)sender{
    self.object=[NSString stringWithFormat:@"2"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
    NSLog(@"%@",object);

}

-(IBAction)ButtonMenu3: (id)sender{
    self.object=[NSString stringWithFormat:@"3"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}


-(IBAction)ButtonMenu4: (id)sender{
    self.object=[NSString stringWithFormat:@"4"];
    [KeySingleton sharedKeySingleton].key =object;
    [master masterAction];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}



- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.file seekToEndOfFile];
    
    NSMutableData *receivedData = [NSMutableData data];
    [receivedData setLength:0];
    [receivedData appendData:data];
    
    [self.file  writeData:receivedData];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [_file closeFile];
    UIImage *image = [UIImage imageWithContentsOfFile:_filePath];
    test.image = image;
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [_file closeFile];
    NSLog(@"%@", error);
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}



- (void)viewDidUnload {
    test = nil;
    [self setButtonTest:nil];
    test2 = nil;
    [_progressString setProgress:0.0];
    [super viewDidUnload];
}
@end
