//
//  MyMasterTableView.h
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//
//@property (strong, nonatomic) IBOutlet UITableView *tableView;
//@property (strong, nonatomic) NSArray *data;

#import <UIKit/UIKit.h>
//#import "MasterDetailDelegate.h"
#import "Cell2.h"
#import "Fugitive.h"
#import "Foundation/Foundation.h"


//
//
@protocol MasterDetailDelegate <NSObject>
@required //metodos obrigatorios
-(void) masterAction;
//metodos opicionais
@optional
@end



@interface MyMasterView : UIViewController
{

}
@property (nonatomic, assign) id <MasterDetailDelegate> delegate;

@property (strong, nonatomic) NSString *object;

-(IBAction)Button1: (id)sender;
-(IBAction)Button2: (id)sender;
-(IBAction)Button3: (id)sender;
-(IBAction)Button4: (id)sender;

@property (nonatomic, strong) Fugitive *detail;

@property (strong, nonatomic) IBOutlet PSTCollectionView *collectionView;
@property (strong, nonatomic) NSArray *data;
@property (strong, nonatomic) NSString *key;
-(void) masterAction;

@end
