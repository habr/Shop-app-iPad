//
//  UIViewController+DescriptionController.m
//  Collection View for iPad
//
//  Created by Kobalt on 10.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "DescriptionController.h"
#import <QuartzCore/QuartzCore.h>
#import "MyMasterView.h"
#import "EXClient.h"
#import "SumSingleton.h"

@interface DescriptionController()
- (void)configureView;
@end

@implementation DescriptionController
@synthesize on,object1;

#pragma mark - Managing the detail item

- (void)setdetail:(id)newdetail
{
    if (_detail != newdetail) {
        _detail = newdetail;

        // Update the view.
        //        [self configureView]; это для страницы с развернутыми данными
    }
}


-(void)configureView
{
    //    NSMutableArray *on = [NSMutableArray array];
    // Update the user interface for the detail item.
    if (self.detail) {
        self.on = self.detail.pk;
        self.titleLDetailabel2.text = self.detail.name;
        self.priceDetailView2.text = self.detail.bounty;
        self.textDetailView2.text = self.detail.desc;
        self.imageDetailView2.image =  [UIImage imageNamed:self.detail.imagename];
   }
}

- (IBAction)addToShopCart:(id)sender {
    
   //     self.object1=[NSString stringWithFormat:on];
    
    
    [SumSingleton sharedSumSingleton].sum = self.on;

    [[EXClient sharedInstance] addBaseForShop];

        
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
       [self configureView]; //это для страницы с развернутыми данными
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.imageDetailView2.image =  [UIImage imageNamed:self.detail.imagename];
    
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}
@end
