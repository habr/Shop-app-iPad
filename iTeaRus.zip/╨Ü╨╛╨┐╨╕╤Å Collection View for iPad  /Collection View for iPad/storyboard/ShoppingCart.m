  //
//  ShoppingCart.m
//  iTea
//
//  Created by Kobalt on 22.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//
#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]

#import "QWE.h"
#import "SumSingleton.h"
#import "ShoppingCart.h"
#import "EXClient.h"
#import "MyCell.h"
#import "MnoSingleton.h"
#import "CustomStepper.h"
#import "MyArraySingleton.h" 
#import "StringSingleton.h"


@interface ShoppingCart()
{
    NSArray *b;
    NSString *adc;
    NSString *azs;

}

@end
@implementation ShoppingCart 
@synthesize values = _values;
@synthesize minValue = _minValue;
@synthesize maxValue = _maxValue;

@synthesize a;

@synthesize data, totalSum;
@synthesize on, arrayA, arrayB; //




- (void)viewDidLoad    
{
    [super viewDidLoad];
    azs= @" ";
    _minValue=0;
    _maxValue=10;
    _values = [MyArraySingleton sharedMyArraySingleton].mAS;
    a = [[NSMutableArray alloc] init];
    _backgroundText.text=@"Нет добавленых товаров";
    [self refreshData];
    NSLog(@"Start %@",_values);
}

- (void)refreshData
{
    [[EXClient sharedInstance] backDataShopItem:^(NSArray *resultReturn) //обновление данных
     {       azs= @"";
         self.data = resultReturn;
         [self.tableView reloadData];
         [self createDefaultValues];
     }];
}

+ (ShoppingCart *)sharedInstance
{
    static dispatch_once_t p = 0;
    __strong static id _sharedObject = nil;
    
    dispatch_once(&p, ^{
        _sharedObject = [[self alloc] init];
    });
    
    return _sharedObject;
}

- (void)refreshload
{
    [self.tableView reloadData];

}

- (UIControl *)newStepper
{
    if (NSStringFromClass([UIStepper class]))
    {
        UIStepper *stepper = [[UIStepper alloc] init]; // # # # # 1.2.3 при первом проходе создаем первый степпер
        stepper.stepValue = 1.0;
        [stepper addTarget:self action:@selector(stepperValueChanged:) forControlEvents:UIControlEventValueChanged];
        return [stepper autorelease];
    }
    else
    {
        CustomStepper *stepper = [[CustomStepper alloc] init];
        stepper.stepValue = 1.0;
        [stepper addTarget:self action:@selector(stepperValueChanged:) forControlEvents:UIControlEventValueChanged];
        return [stepper autorelease];
    }
}


-(void)createDefaultValues{
    NSInteger valuesCount = [self.data count];
    NSInteger defaultValue = 1;

    for(int i = 0; i < valuesCount; i++){
        if ([self.data count] > [_values count]){
        [_values addObject:[NSNumber numberWithInteger:defaultValue]];
        NSLog(@"1 %@",_values);
    }}
}

- (void)stepperValueChanged:(UIStepper *)stepper{
        azs= @"";
    NSInteger no = [stepper tag];
    NSNumber *newValue = [NSNumber numberWithInt:stepper.value];
    if(no<_values.count)
    { //не знаю, для чего эта проверка была у вас, но раз была, то может и правда нужна. Как я понял, это на случай добавления новых строк. В таком случае лучше добивать values дефолтным значением прямо в момент создания новой строки.
        [_values replaceObjectAtIndex:no withObject:newValue];
        NSLog(@"2 %@",_values);
    }
    
    else{
        [_values addObject:newValue];
        NSLog(@"3 %@",_values);
    }
    [_tableView reloadData];
}

//
//- (void)stepperValueChanged:(UIStepper *)stepper{
//    NSInteger no = [stepper tag];
//    NSInteger nomer = [[self.a objectAtIndex:no] intValue];
//    
//    [MnoSingleton sharedMnoSingleton].mno = nomer;
//    [SumSingleton sharedSumSingleton].sum = stepper.value;
//    [[EXClient sharedInstance] stepperValueChangedInBase];
//    [_tableView reloadData];
//}


#pragma mark - Managing the detail item

- (void)setdetail:(id)newdetail
{
    if (_detail != newdetail) {
        _detail = newdetail;
       [self refreshData];
    }
}

- (id)initWithNibName: (NSString *)nibNameOrNil bundle: (NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}


#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.data count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	MyCell *cell = (MyCell *)[tableView dequeueReusableCellWithIdentifier: @"costumcellid"];
    Fugitive *item = [self.data objectAtIndex:indexPath.row];
    
    //получаем массив цен//
    arrayA = [NSMutableArray array];
    arrayB = [NSMutableArray array];
    for (Fugitive *obj in  data)
    {
        [arrayA addObject:obj.ent];
        [arrayB addObject:obj.bounty];
    }
    NSLog(@"arrayA %@",arrayA);
    NSLog(@"arrayB %@",arrayB);
    
    ///////////////////////
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryView = [self newStepper];
    if (NSStringFromClass([UIStepper class]))
    {
        [(UIStepper *)cell.accessoryView setTag:indexPath.row];
        [(UIStepper *)cell.accessoryView setValue:[[_values objectAtIndex:indexPath.row] doubleValue]];
    }
    else
    {
        [(CustomStepper *)cell.accessoryView setTag:indexPath.row];
        [(CustomStepper *)cell.accessoryView setValue:[[_values objectAtIndex:indexPath.row] doubleValue]];
    }
    
    cell.cellTextLabel3.text = item.name;
    cell.cellPriceLabel3.text = item.bounty;
    cell.cellLabelSnipper.text = [[_values objectAtIndex:indexPath.row] stringValue];// [NSString stringWithFormat:@"%d", item.fugitiveID];
    adc = [NSString stringWithFormat:@" %@ %@ %@", item.name, item.bounty, [[_values objectAtIndex:indexPath.row] stringValue]];
    NSLog(@"%@ ", adc);
    
    azs = [azs stringByAppendingString: adc];
    
    [StringSingleton sharedStringSingleton].string = azs;
    
   
    
    NSInteger sum = 0;
    for(int i = 0; i < data.count; i++)
    {
        sum = sum + ([[arrayB objectAtIndex:i] intValue] * [[_values objectAtIndex:i] intValue]);
    }
    NSLog(@"_values %@",_values );
    
    if ([_values count] >= 1)
    {
        _backgroundText.text=@"";
    }
    
    totalSum.text = [NSString stringWithFormat:@"%d", sum];
    NSLog(@"%s",__PRETTY_FUNCTION__);
    self.a=arrayA;
    return cell;
    
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.data removeObjectAtIndex:indexPath.row];
        [_values removeObjectAtIndex:indexPath.row]; // подсчет количества(удаление значения о количестве)
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
        [SumSingleton sharedSumSingleton].sum = [[self.a objectAtIndex:indexPath.row] intValue];
        NSLog(@"a %@",[self.a objectAtIndex:indexPath.row]);
        [self.a removeObjectAtIndex:indexPath.row];  
        NSLog(@"a %@",self.a);
        [_tableView reloadData];        //     
    }
    
    [MyArraySingleton sharedMyArraySingleton].mAS = _values;
    NSLog(@"end %@",_values);

    [[EXClient sharedInstance] deleteBaseForShop];
    if ([self.data  count] < 1)
    {
        _backgroundText.text=@"Нет добавленых товаров";
        totalSum.text=@"0";
    }
}




- (void)viewDidUnload
{
    self.tableView = nil;
    [self setBackgroundText:nil];
    [super viewDidUnload];
}

@end
