//
//  UISplitViewController+MySplitViewController.m
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MySplitViewController.h"


@implementation MySplitViewController

@end
