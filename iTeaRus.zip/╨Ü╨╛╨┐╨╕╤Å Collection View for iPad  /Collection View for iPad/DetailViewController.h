/*
     File: DetailViewController.h
 Abstract: The secondary detailed view controller for this app.

 */

#import <UIKit/UIKit.h>
#import "Cell.h"
#import "Fugitive.h"

@interface DetailViewController : UIViewController

@property (nonatomic, strong) Fugitive *detail;
@property (nonatomic, strong) UIImage *image;

@property (weak, nonatomic) IBOutlet UIImageView *imageDetailView;
@property (weak, nonatomic) IBOutlet UILabel *titleLDetailabel;
@property (weak, nonatomic) IBOutlet UITextView *textDetailView;
@end
