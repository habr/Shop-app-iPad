//
//  KeySingleton.m
//  Collection View for iPad
//
//  Created by Kobalt on 09.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "KeySingleton.h"

@implementation KeySingleton

@synthesize key;

static KeySingleton * sharedKeySingleton = NULL;
+(KeySingleton *)sharedKeySingleton {
    if (!sharedKeySingleton || sharedKeySingleton == NULL) {
		sharedKeySingleton = [KeySingleton new];
	}
    	return sharedKeySingleton;
}

- (void)dealloc {
    self.key = nil;
    [super dealloc];
}

@end