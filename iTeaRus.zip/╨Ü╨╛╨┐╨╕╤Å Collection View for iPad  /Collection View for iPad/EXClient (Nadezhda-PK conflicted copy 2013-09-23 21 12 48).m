//
//  EXClient.m
//  NewsCatalog
//
//  Created by Alex Aleshkov on 6/24/13.
//  Copyright (c) 2013 RogaAndKopita. All rights reserved.
//
#import "Cell.h"
#import "ViewController.h"
#import "EXClient.h"
#import "FMDatabase.h"
#import "Fugitive.h"
#import "MyMasterView.h"
#import "KeySingleton.h"
#import "SumSingleton.h"
#import "MnoSingleton.h"
#define DOCUMENTS [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]


@interface EXClient ()
{
    int32_t captured;
}

@property (nonatomic, strong) FMDatabase *database;
@property (strong, nonatomic) NSString *key;
@property (nonatomic) int32_t sum;
@property (nonatomic) int32_t mno;
@end


@implementation EXClient

- (void)viewDidLoad
{
    [super viewDidLoad];
    captured=0;
} 
+ (EXClient *)sharedInstance
{
    static dispatch_once_t p = 0;
    __strong static id _sharedObject = nil;
    
    dispatch_once(&p, ^{
        _sharedObject = [[self alloc] init];
    });
    
    return _sharedObject;
}

- (id)init
{
    self = [super init];

    if (!self) {
        return nil;
    }

    NSString *const kDatabaseFileName = @"iBountyHunter.sqlite";
   // NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *databasePath = [DOCUMENTS stringByAppendingPathComponent:kDatabaseFileName];
    FMDatabase *database = [FMDatabase databaseWithPath:databasePath];
    if (![database open]) {
        database = nil;
        NSLog(@"Failed to open database");
        return nil;
    }
    self.database = database;
    NSLog(@"%s",__PRETTY_FUNCTION__);
    return self;
}

- (BOOL)hasCachedRssFeed
{
    NSInteger rowsCount = 0;
    FMResultSet *resultSet = [self.database executeQuery:@"SELECT COUNT(*) FROM zfugitive"];
    if ([resultSet next]) {
        rowsCount = [resultSet intForColumnIndex:0];
    }
        return rowsCount;
}

- (NSArray *)fetchCachedRssFeed
{
    FMDatabase *database = self.database;
    _key=[KeySingleton sharedKeySingleton].key;
    NSMutableArray *results = [NSMutableArray array];
    FMResultSet *resultSet = [database executeQuery:@"SELECT * FROM zfugitive WHERE z_opt=@d",_key];  // ORDER BY zname DESC
    NSLog(@"Ключ = %@",_key);
    while ([resultSet next]) {
        Fugitive *item = [[Fugitive alloc] init];
        item.pk = [resultSet intForColumn:@"Z_PK"];
        item.ent = [resultSet stringForColumn:@"Z_ENT"];
        item.captured = [resultSet boolForColumn:@"zcaptured"];
        item.captdate = [resultSet doubleForColumn:@"zcaptdate"];
        item.capturedLat = [resultSet doubleForColumn:@"zcapturedLat"];
        item.lastSeenLat = [resultSet doubleForColumn:@"zlastSeenLat"];
        item.desc = [resultSet stringForColumn:@"zdesc"];
        item.capturedLon = [resultSet doubleForColumn:@"zcapturedLon"];
        item.image = [resultSet dataForColumn:@"zimage"];
        item.lastSeenLon =  [resultSet doubleForColumn:@"zlastSeenLon"];
        item.bounty = [resultSet stringForColumn:@"zbounty"];
        item.lastSeenDesc = [resultSet stringForColumn:@"zlastSeenDesc"];
        item.imagename = [resultSet stringForColumn:@"zimagename"];
        item.name = [resultSet stringForColumn:@"zname"];
        item.fugitiveID = [resultSet intForColumn:@"zfugitiveID"];
        [results addObject:item];
    }
    return results;
}

- (void)fetchRssFeedCachedBlock:(EXClientSuccessBlock)cachedBlock {
     if (cachedBlock) {
        NSArray *cachedFeed = [self fetchCachedRssFeed];
         cachedBlock(cachedFeed);
    }
}
 

- (void)addBaseForShop {
    FMDatabase *database = self.database;
    if([database open]) {
        Fugitive *item = [[Fugitive alloc] init];
        _sum=[SumSingleton sharedSumSingleton].sum;
        NSString *queryStr;
        queryStr=  [NSString stringWithFormat:@"SELECT * FROM zfugitive WHERE Z_PK = %d",_sum]; 
        NSLog(@"SELECT * FROM zfugitive WHERE Z_PK = %d",_sum);   
        FMResultSet *resultSet =[self.database executeQuery:queryStr];
        while ([resultSet next]) {
            item.captured = [resultSet boolForColumn:@"zcaptured"];
        }  
        if (!(item.captured == YES)) {
            captured=captured+1;
            NSString *queryStr;
            NSLog(@"Итем куплен = %d",_sum);
            queryStr=  [NSString stringWithFormat:@"UPDATE zfugitive SET ZCAPTURED = %d WHERE Z_PK = %d",captured,_sum];
            NSLog(@"UPDATE zfugitive SET ZCAPTURED = %d WHERE Z_PK = %d",captured,_sum);
            [self.database  executeUpdate:queryStr];
        }
        else {
        UIAlertView *simpleAlert = [[UIAlertView alloc] initWithTitle:@"Товар добавлен"
                                                              message:@"Товар уже в корзине"
                                                             delegate:self
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
        [simpleAlert show];
        [simpleAlert release];
        }
    }
}

- (void)stepperValueChangedInBase {
    FMDatabase *database = self.database;
    if([database open]){
        NSString *queryStr;
        _mno = [MnoSingleton sharedMnoSingleton].mno;
        _sum=[SumSingleton sharedSumSingleton].sum;
        NSLog(@"Количество = %d",_sum);
        queryStr=  [NSString stringWithFormat:@"UPDATE zfugitive SET zfugitiveID = %d WHERE Z_PK = %d",_sum,_mno];
        NSLog(@"UPDATE zfugitive SET zfugitiveID = %d WHERE Z_PK = %d",_sum,_mno);
        [self.database  executeUpdate:queryStr];
    }
}

- (void)deleteBaseForShop {
    FMDatabase *database = self.database;
    if([database open]){
        NSString *queryStr;
        _sum=[SumSingleton sharedSumSingleton].sum;
        NSLog(@"Итем = %d удален ",_sum);
        queryStr=  [NSString stringWithFormat:@"UPDATE zfugitive SET ZCAPTURED = 0 WHERE Z_PK = %d",_sum];
        NSLog(@"UPDATE zfugitive SET ZCAPTURED = 0 WHERE Z_PK = %d",_sum);
        [self.database  executeUpdate:queryStr];
    }
}

- (void)backDataShopItem:(EXClientBackItem)cachedItem {
    if (cachedItem) {
        NSArray *cachedReturn = [self seeBaseForShop];
        cachedItem(cachedReturn);
    }
}

- (NSArray *)seeBaseForShop  // выбрать купленные итемы
{
    FMDatabase *database = self.database;
    if([database open]) {
        NSMutableArray *resultsReturn = [NSMutableArray array];
        NSString *queryStr;
        queryStr=  [NSString stringWithFormat:@"SELECT * FROM zfugitive WHERE (ZCAPTURED >0) ORDER BY  ZCAPTURED ASC"]; // ORDER BY zname DESC
        NSLog(@"SELECT * FROM zfugitive WHERE (ZCAPTURED >0) ORDER BY  ZCAPTURED ASC");   // ORDER BY zname DESC
        FMResultSet *resultSet =[self.database executeQuery:queryStr];
        while ([resultSet next]) {
            Fugitive *item = [[Fugitive alloc] init];
            item.pk = [resultSet intForColumn:@"Z_PK"];
            item.ent = [resultSet stringForColumn:@"Z_ENT"];
            item.captured = [resultSet boolForColumn:@"zcaptured"];
            item.captdate = [resultSet doubleForColumn:@"zcaptdate"];
            item.capturedLat = [resultSet doubleForColumn:@"zcapturedLat"];
            item.lastSeenLat = [resultSet doubleForColumn:@"zlastSeenLat"];
            item.desc = [resultSet stringForColumn:@"zdesc"];
            item.capturedLon = [resultSet doubleForColumn:@"zcapturedLon"];
            item.image = [resultSet dataForColumn:@"zimage"];
            item.lastSeenLon =  [resultSet doubleForColumn:@"zlastSeenLon"];
            item.bounty = [resultSet stringForColumn:@"zbounty"];
            item.lastSeenDesc = [resultSet stringForColumn:@"zlastSeenDesc"];
            item.imagename = [resultSet stringForColumn:@"zimagename"];
            item.name = [resultSet stringForColumn:@"zname"];
            item.fugitiveID = [resultSet intForColumn:@"zfugitiveID"];
            [resultsReturn addObject:item];
            }
            return resultsReturn;
            NSLog(@"%s",__PRETTY_FUNCTION__);
        }
}


@end