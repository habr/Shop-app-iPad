//
//  QWE.h
//  iTea
//
//  Created by Kobalt on 24.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface QWE : UIViewController //<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *familiya;
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *sername;
@property (strong, nonatomic) IBOutlet UITextField *oblast;
@property (strong, nonatomic) IBOutlet UITextField *city;
@property (strong, nonatomic) IBOutlet UITextField *index;
@property (strong, nonatomic) IBOutlet UITextField *street;
@property (strong, nonatomic) IBOutlet UITextField *town;
@property (strong, nonatomic) IBOutlet UITextField *camp;
@property (strong, nonatomic) IBOutlet UITextField *kv;
@property (strong, nonatomic) IBOutlet UITextField *email;
@property (strong, nonatomic) IBOutlet UITextField *telnamber;


@property(nonatomic,assign) NSMutableData *receivedData;

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;

@end
