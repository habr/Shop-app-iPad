//
//  FMDatabase+SharedInstance.h
//  Collection View for iPad
//
//  Created by Kobalt on 30.06.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "FMDatabase.h"

@interface FMDatabase (SharedInstance)

+(FMDatabase *)sharedInstance;
+(void)setSharedInstance:(FMDatabase *)SharedInstance;

@end
