//
//  KeySingleton.h
//  Collection View for iPad
//
//  Created by Kobalt on 09.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeySingleton : NSObject {
    NSString *key;
}
@property (nonatomic, retain) NSString *key;

+(KeySingleton *)sharedKeySingleton;

@end