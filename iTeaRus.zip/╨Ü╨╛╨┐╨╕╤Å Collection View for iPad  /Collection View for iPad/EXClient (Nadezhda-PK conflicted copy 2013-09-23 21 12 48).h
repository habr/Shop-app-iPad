//
//  EXClient.h
//  NewsCatalog
//
//  Created by Alex Aleshkov on 6/24/13.
//  Copyright (c) 2013 RogaAndKopita. All rights reserved.
//


#import <Foundation/Foundation.h>


typedef void(^EXClientSuccessBlock)(NSArray *result);
typedef void(^EXClientFailureBlock)(NSError *error);
typedef void(^EXClientBackItem)(NSArray *resultReturn);


@interface EXClient : NSObject

+ (EXClient *)sharedInstance;

- (BOOL)hasCachedRssFeed;
- (void)fetchRssFeedCachedBlock:(EXClientSuccessBlock)cachedBlock;
- (void)backDataShopItem:(EXClientBackItem)cachedItem;
- (void)addBaseForShop;
- (void)stepperValueChangedInBase;
- (void)deleteBaseForShop;

- (NSArray *)seeBaseForShop;

@property (nonatomic, retain) IBOutlet UIProgressView *downloadProgress;

@end
