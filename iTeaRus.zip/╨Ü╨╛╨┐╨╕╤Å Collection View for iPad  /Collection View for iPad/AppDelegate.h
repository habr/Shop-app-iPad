//
//  AppDelegate.h
//  Collection View for iPad
//
//  Created by Kobalt on 17.06.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "Fugitive.h"

#import "PSTCollectionView.h" 

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) UINavigationController *navigationController2;


/*
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;


@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * imagename;
@property (nonatomic, retain) NSDecimalNumber * bounty;
@property (nonatomic, retain) NSNumber * fugitiveID;
@property (nonatomic, retain) NSString * desc;


- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;
*/

@end
