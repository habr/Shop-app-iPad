//
//  Fugitive.m
//  Collection View for iPad
//
//  Created by Kobalt on 25.06.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "Fugitive.h"

@interface Fugitive (Private)
@end

@implementation Fugitive

@synthesize pk,ent,opt,captured,captdate,capturedLat,lastSeenLat,desc,capturedLon,image,lastSeenLon,bounty,lastSeenDesc,imagename,name,fugitiveID;


/*
@dynamic captured;
@dynamic captdate;
@dynamic capturedLat;
@dynamic lastSeenLat;
@dynamic desc;
@dynamic capturedLon;
@dynamic image;
@dynamic lastSeenLon;
@dynamic bounty;
@dynamic lastSeenDesc;
@dynamic imagename;
@dynamic name;
@dynamic fugitiveID;

-(NSArray *)imagesFromItemDescription
{
    if (self.itemDescription) {
        return [self imagesFromHTMLString:self.itemDescription];
    }
    
    return nil;
}

-(NSArray *)imagesFromContent
{
    if (self.content) {
        return [self imagesFromHTMLString:self.content];
    }
    
    return nil;
} */

@end
