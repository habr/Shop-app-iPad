//
//  EXSplashScreenViewController.m
//  NewsCatalog
//
//  Created by Alex Aleshkov on 5/13/13.
//  Copyright (c) 2013 RogaAndKopita. All rights reserved.
//


#import "EXSplashScreenViewController.h"
#import "UIImage+ImageNamed568.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "FMDatabase+SharedInstance.h"
#import "EXClient.h"
//#import "MyDetailView.h"
#import "MyMasterView.h"
#import "Fugitive.h"


@implementation EXSplashScreenViewController
@synthesize window = _window;
@synthesize navigationController;
@synthesize navigationController2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{ 
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    NSLog(@"----------------------");
    UIImage *image = [UIImage imageNamed568:@"Default"];
    self.imageView.image = image;
}

-(IBAction)buttonAction:(id)sender
{
    [self performSegueWithIdentifier:@"segueEnter" sender:self];
//segueEnter
}
@end
