//
//  MyDetailView.m
//  Collection View for iPad
//
//  Created by Kobalt on 06.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "MyDetailView.h"
#import "Cell2.h"
#import "FMDatabase+SharedInstance.h"
#import "Fugitive.h"
#import "EXClient.h"
#import "MyMasterView.h"
#import "KeySingleton.h"


@interface MyDetailView ()
//-(void) masterAction;
-(void)configureView;
@end

@implementation MyDetailView
@synthesize key;


- (void)viewDidLoad
{
    [super viewDidLoad];
    [KeySingleton sharedKeySingleton].key =@"1";
	// Do any additional setup after loading the view, typically from a nib.
    [self refreshData];
}

#pragma mark - Managing the detail item

- (void)setdetail:(id)newdetail
{
    if (_detail != newdetail) {
        _detail = newdetail;
        
        [self refreshData];
    }
}
//выввести коллекцию на борд

- (id)initWithNibName: (NSString *)nibNameOrNil bundle: (NSBundle *)nibBundleOrNil
{self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;}

- (void)configureView{
    // Update the user interface for the detail item.
    if (self.detail) {
      //  self.detailDescriptionLabel.text = [self.detailItem description];
    }}


- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return [self.data count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    static NSString *const CellID = @"cellID2";       // связка ячейки кода через идентефикатор
    
    Cell2 *cell2 = [cv dequeueReusableCellWithReuseIdentifier:CellID forIndexPath:indexPath];   // создание ячейки
    
    Fugitive *item = [self.data objectAtIndex:indexPath.row];
    
    cell2.cellTextLabel2.text = item.name;

    cell2.cellImageView2.image = [UIImage imageNamed:item.imagename];
    
    NSLog(@"%d", indexPath.row);
//                    [self.delegate masterAction:item];
    return cell2;
    
}
/*
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSIndexPath *selectedIndexPath = [[self.collectionView indexPathsForSelectedItems] objectAtIndex:0];
    
    
    Fugitive *item = [self.data objectAtIndex:selectedIndexPath.row];
    [segue.destinationViewController setDetail:item];
}
*/


- (void)refreshData
{
    [[EXClient sharedInstance] fetchRssFeedCachedBlock:^(NSArray *result) {
        self.data = result;
        [self.collectionView reloadData];
    }];
}



 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
         if ([[segue identifier] isEqualToString:@"ShowSightingDetails"]) {
     NSIndexPath *selectedIndexPath = [[self.collectionView indexPathsForSelectedItems] objectAtIndex:0];
     Fugitive *item = [self.data objectAtIndex:selectedIndexPath.row];
             [segue.destinationViewController setDetail:item];}
 }

#pragma mark - Master Detail Delegate

-(void) masterAction;
{
    [self refreshData];
}

@end

