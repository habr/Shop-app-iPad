/*
 File: ViewController.m
 Abstract: The primary view controller for this app.

 
 Copyright (C) 2012 Apple Inc. All Rights Reserved.
 
 */

#import "ViewController.h"
#import "DetailViewController.h"
#import "Cell.h"
#import "FMDatabase+SharedInstance.h"
#import "Fugitive.h"
#import "EXClient.h"


@implementation ViewController
 
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title=@"iTea";
    [self refreshData];
    
}

//////////////////////////////////////////////////////////////////////////
- (NSInteger)collectionView:(PSTCollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return [self.data count];
}
//////////////////////////////////////////////////////////////////////////

- (PSUICollectionViewCell *)collectionView:(PSUICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    static NSString *const CellID = @"cellID";       // связка ячейки кода через идентефикатор
    
    Cell *cell = [cv dequeueReusableCellWithReuseIdentifier:CellID forIndexPath:indexPath];   // создание ячейки
    
    Fugitive *item = [self.data objectAtIndex:indexPath.row];
    cell.cellTextLabel.text = item.name;

    cell.cellImageView.image = [UIImage imageNamed:item.imagename];
    
    
    return cell;
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
 NSIndexPath *selectedIndexPath = [[self.collectionView indexPathsForSelectedItems] objectAtIndex:0];
         Fugitive *item = [self.data objectAtIndex:selectedIndexPath.row];
        [segue.destinationViewController setDetail:item];
    }

- (void)refreshData
{
    [[EXClient sharedInstance] fetchRssFeedCachedBlock:^(NSArray *result) {
        self.data = result;
        [self.collectionView reloadData];
    }];

}
-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}
-(void)reloadData
{
    FMDatabase *database=[FMDatabase sharedInstance];
    
    NSMutableArray *results = [NSMutableArray array];
    FMResultSet *resultSet = [database executeQuery:@"SELECT * FROM zfugitive WHERE z_opt=%d ORDER BY zname DESC"];
    while ([resultSet next]) {
        Fugitive *item = [[Fugitive alloc] init];
        
        item.opt = [resultSet intForColumn:@"z_opt"];
        item.captured = [resultSet boolForColumn:@"zcaptured"];
        item.captdate = [resultSet doubleForColumn:@"zcaptdate"];
        item.capturedLat = [resultSet doubleForColumn:@"zcapturedLat"];
        item.lastSeenLat = [resultSet doubleForColumn:@"zlastSeenLat"];
        item.desc = [resultSet stringForColumn:@"zdesc"];
        item.capturedLon = [resultSet doubleForColumn:@"zcapturedLon"];
        item.image = [resultSet dataForColumn:@"zimage"];
        item.lastSeenLon =  [resultSet doubleForColumn:@"zlastSeenLon"];
        item.lastSeenDesc = [resultSet stringForColumn:@"zlastSeenDesc"];
        item.imagename = [resultSet stringForColumn:@"zimagename"];
        item.name = [resultSet stringForColumn:@"zname"];
        item.fugitiveID = [resultSet intForColumn:@"zfugitiveID"];

        [results addObject:item];
    }
    self.data=results;
}



@end
