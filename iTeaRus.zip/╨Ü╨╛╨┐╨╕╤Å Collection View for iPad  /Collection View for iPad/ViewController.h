/*
 File: ViewController.h
 Abstract: The primary view controller for this app.
 
 */

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "PSTCollectionView.h"

@interface ViewController : PSUICollectionViewController <PSUICollectionViewDelegate, PSUICollectionViewDataSource>



@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) NSArray *data;
//@property (strong, nonatomic) NSMutableArray *results;
@end
