/*
     File: Cell.h
 Abstract: Custom collection view cell for image and its label.
 
*/

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "PSTCollectionView.h"

@interface Cell : PSUICollectionViewCell

@property (strong, nonatomic) IBOutlet UILabel *cellTextLabel;
@property (strong, nonatomic) IBOutlet UIImageView *cellImageView;

@end
