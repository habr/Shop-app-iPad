//
//  EXSplashScreenViewController.h
//  NewsCatalog
//
//  Created by Alex Aleshkov on 5/13/13.
//  Copyright (c) 2013 RogaAndKopita. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface EXSplashScreenViewController : UIViewController


@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) UINavigationController *navigationController2;
@property (strong, nonatomic) IBOutlet UIButton *buttonEnter;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@end
