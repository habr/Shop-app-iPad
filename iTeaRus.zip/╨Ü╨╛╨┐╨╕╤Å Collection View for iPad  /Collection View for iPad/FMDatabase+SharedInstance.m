//
//  FMDatabase+SharedInstance.m
//  Collection View for iPad
//
//  Created by Kobalt on 30.06.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "FMDatabase+SharedInstance.h"

static FMDatabase *sDatabase=nil;

@implementation FMDatabase (SharedInstance)

+(FMDatabase *)sharedInstance
{
    return sDatabase;
}

+(void)setSharedInstance:(FMDatabase *)sharedInstance
{
    sDatabase = sharedInstance;
}

@end
