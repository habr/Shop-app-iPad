//
//  Fugitive.h
//  Collection View for iPad
//
//  Created by Kobalt on 25.06.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Fugitive : NSObject
@property (nonatomic) int32_t pk;
@property (nonatomic, retain) NSString * ent;
@property (nonatomic) int32_t opt;
@property (nonatomic) BOOL captured;
@property (nonatomic) NSTimeInterval captdate;
@property (nonatomic) double capturedLat;
@property (nonatomic) double lastSeenLat;
@property (nonatomic, retain) NSString * desc;
@property (nonatomic) double capturedLon;
@property (nonatomic, retain) NSData * image;
@property (nonatomic) double lastSeenLon;
@property (nonatomic, retain) NSString * bounty;
@property (nonatomic, retain) NSString * lastSeenDesc;
@property (nonatomic, retain) NSString * imagename;
@property (nonatomic, retain) NSString * name;
@property (nonatomic) int32_t fugitiveID;

//-(NSArray *)imagesFromItemDescription;
//-(NSArray *)imagesFromContent;

@end
