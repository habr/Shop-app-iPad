//
//  QWE.m
//  iTea
//
//  Created by Kobalt on 24.07.13.
//  Copyright (c) 2013 Kobalt. All rights reserved.
//

#import "QWE.h"
#import "StringSingleton.h"
#define MAX_LENGTH 45
#define urlHost @"http://ichay.hostenko.com/con.php"


@implementation QWE
{
    NSString *zakaz;
    NSString *zapros;
    NSString *sendString;
    BOOL errorvalid1;
    BOOL errorvalid2;
    BOOL errorvalid3;
    BOOL errorvalid4;
    BOOL errorvalid5;
    BOOL errorvalid6;
    BOOL errorvalid7;
    BOOL errorvalid8;
    BOOL errorvalid9;
    BOOL errorvalid10;
    BOOL errorvalid11;
    BOOL errorvalid12;
}
@synthesize receivedData;

- (void)viewDidLoad
{
    zakaz = [StringSingleton sharedStringSingleton].string;
    NSLog(@"%@ ", zakaz);

//    @property (strong, nonatomic) IBOutlet UITextField *name; ограничение только буквы не больше 20 
//    @property (strong, nonatomic) IBOutlet UITextField *sername; ограничение только буквы не больше 20
//    @property (strong, nonatomic) IBOutlet UITextField *city; ограничение только буквы не больше 25
//    @property (strong, nonatomic) IBOutlet UITextField *index; только цыфры не больше 6 и только целые
//    @property (strong, nonatomic) IBOutlet UITextField *street; только буквы 40
//    @property (strong, nonatomic) IBOutlet UITextField *towncamp; цыфры и буквы
//    @property (strong, nonatomic) IBOutlet UITextField *kv; только цыфры 
//    @property (strong, nonatomic) IBOutlet UITextField *email; 
//    @property (strong, nonatomic) IBOutlet UITextField *telnamber; только цыфры и скобки +
//    
    
    
}

- (BOOL) validateAlpha: (NSString *) candidate {
    return [self validateStringInCharacterSet:candidate characterSet:[NSCharacterSet letterCharacterSet]];
}

- (BOOL) validateStringInCharacterSet: (NSString *) string characterSet: (NSMutableCharacterSet *) characterSet {
    // Since we invert the character set if it is == NSNotFound then it is in the character set.
    return ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) ? NO : YES;
}

- (BOOL) validateAlphanumeric: (NSString *) candidate {
    return [self validateStringInCharacterSet:candidate characterSet:[NSCharacterSet alphanumericCharacterSet]];
}

- (BOOL) validateAlphanumericDash: (NSString *) candidate {
    NSMutableCharacterSet *characterSet = [NSMutableCharacterSet alphanumericCharacterSet];
    [characterSet addCharactersInString:@"-_."];
    return [self validateStringInCharacterSet:candidate characterSet:characterSet];
}

- (BOOL) validateAlphanumericSlash: (NSString *) candidate {
    NSMutableCharacterSet *characterSet = [NSMutableCharacterSet alphanumericCharacterSet];
    [characterSet addCharactersInString:@"0-9/."];
    return [self validateStringInCharacterSet:candidate characterSet:characterSet];
}

- (BOOL) validateAlphaOnlyNumeric: (NSString *) candidate {
    NSMutableCharacterSet *characterSet = [NSMutableCharacterSet alphanumericCharacterSet];
    [characterSet addCharactersInString:@"0-9."];
    return [self validateStringInCharacterSet:candidate characterSet:characterSet];
}

- (BOOL) validateTelefon: (NSString *) candidate {
    NSMutableCharacterSet *characterSet = [NSMutableCharacterSet alphanumericCharacterSet];
    [characterSet addCharactersInString:@"0-9()+-."];
    return [self validateStringInCharacterSet:candidate characterSet:characterSet];
}

- (BOOL) validateEmail: (NSString *) candidate
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@ "SELF MATCHES %@ ", emailRegex];
    return [emailTest evaluateWithObject:candidate];
}

- (BOOL)validateLenge:(UITextField *)textField
{
    NSUInteger newLength = [textField.text length];
    
    if ((newLength < 45) && (newLength > 0)){
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)validateZero:(UITextField *)textField // проверка на пустоту
{
    NSUInteger newLength = [textField.text length];
    
    if (!newLength == 0) {
        return YES; 
    } else {
        return NO;  
    }
}

- (IBAction)postmessage:(id)sender {
    
    if (([self validateLenge:_familiya]) && ([self validateAlpha:_familiya.text])){                   ///
        errorvalid1=YES;
    } else {
        _familiya.text = @"Только буквы, без пробелов";
        errorvalid1=NO;
    }
    
    if (([self validateLenge:_name]) && ([self validateAlpha:_name.text]))  {                     ///
        //Email Address is valid
        errorvalid2 = YES;
    } else {
        //Email Address is not Valid
        _name.text = @"Только буквы, без пробелов";
        errorvalid2 = NO;
    }
    
    if (([self validateLenge:_sername]) && ([self validateAlpha:_sername.text]))  {                  ///
        //Email Address is valid
        errorvalid3 = YES;
    } else {
        //Email Address is not Valid
        _sername.text = @"Только буквы, без пробелов";
        errorvalid3 = NO;
    }
    
    if (([self validateLenge:_oblast]) && ([self validateAlphanumericDash:_oblast.text]))  {          ///
        //Email Address is valid
        errorvalid4 = YES;
    } else {
        //Email Address is not Valid
        _oblast.text = @"Только буквы, цифры и тире, без пробелов";
        errorvalid4 = NO;
    }
    
    if (([self validateLenge:_city]) && ([self validateAlphanumericDash:_city.text]))  {          ///
        //Email Address is valid
        errorvalid5 = YES;
    } else {
        //Email Address is not Valid
        _city.text = @"Только буквы, цифры и тире, без пробелов";
        errorvalid5 = NO;
    }
    
    if (([self validateLenge:_index]) && ([self validateAlphaOnlyNumeric:_index.text]))  {             /// ##### только цыфры
        //Email Address is valid
        errorvalid6 = YES;
    } else {
        //Email Address is not Valid
        _index.text = @"Только цифры, без пробелов";
        errorvalid6 = NO;
    }
    
    if (([self validateLenge:_street]) && ([self validateAlphanumeric:_street.text]))  {            ///
        //Email Address is valid
        errorvalid7 = YES;
    } else {
        //Email Address is not Valid
        _street.text = @"Только буквы и цифры, без пробелов";
        errorvalid7 = NO;
    }
    
    if (([self validateLenge:_town]) && ([self validateAlphanumericSlash:_town.text]))  {      ///
        //Email Address is valid
        errorvalid8 = YES;
    } else {
        //Email Address is not Valid
        _town.text = @"Только цифры и /, без пробелов ";
        errorvalid8 = NO;
    }
    
    if (([self validateLenge:_camp]) && ([self validateAlphanumericSlash:_camp.text]))  {
        errorvalid9 = YES;
    } else {
        _camp.text = @"Только цифры и /, без пробелов ";
        errorvalid9 = NO;
        if ([self validateZero:_camp]){
            errorvalid9 = YES;
        _camp.text = @"";
        }
    }
    
    
    if(([self validateLenge:_kv]) && ([self validateAlphaOnlyNumeric:_kv.text])) {                  /// ##### только цыфры
        //Email Address is valid
        NSLog(@"ОК");
        errorvalid10 = YES;
    } else {
        _kv.text = @"*Неправильный номер*";
        errorvalid10 = NO;
        if ([self validateZero:_kv]){
            errorvalid10 = YES;
            _kv.text = @"";
        }
    }
    
    if(([self validateLenge:_email]) && ([self validateEmail:_email.text])) {                      //
        //Email Address is valid
        NSLog(@"ОК");
        errorvalid11 = YES;
    } else {
        //Email Address is not Valid
        _email.text = @"*Неправильное имя почты*";
        errorvalid11 = NO;
    }
    
    if (([self validateLenge:_telnamber]) && ([self validateTelefon:_telnamber.text]))  {                /// ##### 
        errorvalid12 = YES;
    } else {
        _telnamber.text = @"*Только цифры*";
        errorvalid12 = NO;
    }
    
    if ((errorvalid1==YES)&&(errorvalid2==YES) && (errorvalid3==YES)&&(errorvalid4==YES) && (errorvalid5==YES)&&(errorvalid6==YES) && (errorvalid7==YES)&&(errorvalid8==YES) && (errorvalid11==YES)&&(errorvalid12==YES)) {
    sendString = [NSString stringWithFormat:@"host=k23.hostenko.com&db=yshffb4129_60948&user=ybtzhek129_60948&password=ARZt4129rFK6f&familiya=%@&name=%@&sername=%@&oblast=%@&city=%@&index=%@&street=%@&town=%@&camp=%@&kv=%@&email=%@&telnamber=%@&zakaz=%@", _familiya.text,  _name.text, _sername.text, _oblast.text, _city.text, _index.text, _street.text, _town.text, _camp.text, _kv.text, _email.text, _telnamber.text, zakaz];
        NSLog(@"%@", sendString);
//
//host=k23.hostenko.com&db=yshffb4129_60948&user=ybtzhek129_60948&password=ARZt4129rFK6f

//    NSString *messageString = sendString;
////////////////
        
        
        NSString *ads= ([NSString stringWithFormat:@"%@?%@", urlHost, sendString]);
        NSLog(@"%@", ads);
        

        
        NSString *encodedUrl = [ads stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
        
        NSLog(@"URL - %@", encodedUrl);              // Checking the url
        
        NSMutableURLRequest *theRequest= [NSMutableURLRequest requestWithURL:[NSURL URLWithString:encodedUrl]
                                                                 cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                             timeoutInterval:10.0];
        
        NSURLConnection *connection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self startImmediately:YES];

        
        if (connection) {
            // соединение началось
            NSLog(@"Connecting...");
            // создаем NSMutableData, чтобы сохранить полученные данные
            receivedData = [[NSMutableData data] retain];
        } else {
            // при попытке соединиться произошла ошибка
            NSLog(@"Connection error!");
        }
    }
}
    
    - (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
    {
        // получен ответ от сервера
        [receivedData setLength:0];
    }
    
    - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
    {
        // добавляем новые данные к receivedData
        [receivedData appendData:data];
    }
    
    - (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    // освобождаем соединение и полученные данные
    [connection release];
    [receivedData release];
    
    // выводим сообщение об ошибке
    NSString *errorString = [[NSString alloc] initWithFormat:@"Connection failed! Error - %@ %@ %@",
                             [error localizedDescription],
                             [error description],
                             [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]];
        NSLog(@"%@", errorString);
    [errorString release];
}
    
    
    - (void)connectionDidFinishLoading:(NSURLConnection *)connection {
        // данные получены
        // здесь можно произвести операции с данными
        
        // можно узнать размер загруженных данных
        //NSString *dataString = [[NSString alloc] initWithFormat:@"Received %d bytes of data",[receivedData length]];
        
        // если ожидаемые полученные данные - это строка, то можно вывести её
        NSString *dataString = [[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding];
        
        if ([dataString isEqual: @"OK"]){
        
        

        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Заказ принят"
                                                        message:@"С вами скоро свяжуться по почте"
                                                       delegate:self
                                              cancelButtonTitle:@"Спасибо"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];                                                                    
        
        }
        
        
        
        // освобождаем соединение и полученные данные
        [connection release];
        [receivedData release];
        [dataString release];
    }


        //////////////////////////////////
-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return interfaceOrientation == UIInterfaceOrientationLandscapeLeft;
}

- (void)viewDidUnload {
    [self setFamiliya:nil];
    [self setName:nil];
    [self setSername:nil];
    [self setCity:nil];
    [self setIndex:nil];
    [self setStreet:nil];
    [self setTown:nil];
    [self setKv:nil];
    [self setEmail:nil];
    [self setTelnamber:nil];
    [self setOblast:nil];
    [self setCamp:nil];

    [super viewDidUnload];
}

@end
