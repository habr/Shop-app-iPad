//
//  ZHCustomSegue.h
//  CustomSegue
//
//  Created by Zakir on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZHCustomSegue : UIStoryboardSegue

@end
