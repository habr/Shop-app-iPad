//
//  UIImage+ImageNamed568.h
//
//  Created by Alexey Aleshkov on 31.10.12.
//  Copyright (c) 2012 Webparadox, LLC. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface UIImage (ImageNamed568)

+ (UIImage *)imageNamed568:(NSString *)name;

@end
